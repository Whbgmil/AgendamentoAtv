import java.io.*;
import java.util.*;

class Usuario {
    String login, senha, nome, tipo;

    Usuario(String login, String senha, String nome, String tipo) {
        this.login = login;
        this.senha = senha;
        this.nome = nome;
        this.tipo = tipo;
    }
}

class Paciente {
    String cpf, nome, telefone, dataNasc;

    Paciente(String cpf, String nome, String telefone, String dataNasc) {
        this.cpf = cpf;
        this.nome = nome;
        this.telefone = telefone;
        this.dataNasc = dataNasc;
    }
}

class Consulta {
    String id, cpfPaciente, data, hora, status;

    Consulta(String id, String cpfPaciente, String data, String hora) {
        this.id = id;
        this.cpfPaciente = cpfPaciente;
        this.data = data;
        this.hora = hora;
        this.status = "AGENDADA";
    }
}

public class SistemaAgendamento {
    static ArrayList<Usuario> usuarios = new ArrayList<>();
    static ArrayList<Paciente> pacientes = new ArrayList<>();
    static ArrayList<Consulta> consultas = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);
    static Usuario usuarioAtual;
    static int contadorConsultas = 1;

    public static void main(String[] args) {
        iniciarSistema();
        fazerLogin();
        menuPrincipal();
    }

    static void iniciarSistema() {
        usuarios.add(new Usuario("admin", "123", "Admin", "ADMIN"));
        usuarios.add(new Usuario("operador", "123", "Operador", "OPERADOR"));

        pacientes.add(new Paciente("11122233344", "João Silva", "(11) 99999-1111", "15/03/1980"));
        pacientes.add(new Paciente("22233344455", "Maria Santos", "(11) 98888-2222", "20/07/1992"));

        consultas.add(new Consulta("C001", "11122233344", "10/02/2026", "14:00"));
        consultas.add(new Consulta("C002", "22233344455", "12/02/2026", "10:30"));
        contadorConsultas = 3;
    }

    static void fazerLogin() {
        System.out.println("=== SISTEMA DE AGENDAMENTO ===");

        while (usuarioAtual == null) {
            System.out.print("Login: ");
            String login = sc.nextLine();
            System.out.print("Senha: ");
            String senha = sc.nextLine();

            for (Usuario u : usuarios) {
                if (u.login.equals(login) && u.senha.equals(senha)) {
                    usuarioAtual = u;
                    log("Login realizado");
                    System.out.println("Bem-vindo, " + u.nome + "!");
                    return;
                }
            }
            System.out.println("Login ou senha incorretos!");
        }
    }

    static void menuPrincipal() {
        while (true) {
            System.out.println("\n=== MENU PRINCIPAL ===");

            if (usuarioAtual.tipo.equals("ADMIN")) {
                System.out.println("1. Cadastrar Paciente");
                System.out.println("2. Listar Pacientes");
                System.out.println("3. Editar Paciente");
                System.out.println("4. Remover Paciente");
                System.out.println("5. Agendar Consulta");
                System.out.println("6. Listar Consultas");
                System.out.println("7. Cancelar Consulta");
                System.out.println("8. Relatórios");
                System.out.println("9. Cadastrar Usuário");
                System.out.println("0. Sair");
            } else {
                System.out.println("1. Cadastrar Paciente");
                System.out.println("2. Listar Pacientes");
                System.out.println("5. Agendar Consulta");
                System.out.println("6. Listar Consultas");
                System.out.println("7. Cancelar Consulta");
                System.out.println("0. Sair");
            }

            System.out.print("Escolha: ");
            int op = Integer.parseInt(sc.nextLine());

            if (op == 0) break;

            switch (op) {
                case 1: cadastrarPaciente(); break;
                case 2: listarPacientes(); break;
                case 3: 
                    if (usuarioAtual.tipo.equals("ADMIN")) editarPaciente(); 
                    else System.out.println("Acesso negado!");
                    break;
                case 4: 
                    if (usuarioAtual.tipo.equals("ADMIN")) removerPaciente(); 
                    else System.out.println("Acesso negado!");
                    break;
                case 5: agendarConsulta(); break;
                case 6: listarConsultas(); break;
                case 7: cancelarConsulta(); break;
                case 8: 
                    if (usuarioAtual.tipo.equals("ADMIN")) relatorios(); 
                    else System.out.println("Acesso negado!");
                    break;
                case 9: 
                    if (usuarioAtual.tipo.equals("ADMIN")) cadastrarUsuario(); 
                    else System.out.println("Acesso negado!");
                    break;
                default: System.out.println("Opção inválida!");
            }
        }
        log("Logout do sistema");
        System.out.println("Sistema encerrado!");
    }

    static void cadastrarPaciente() {
        System.out.println("\n--- CADASTRAR PACIENTE ---");

        System.out.print("CPF: ");
        String cpf = sc.nextLine();

        for (Paciente p : pacientes) {
            if (p.cpf.equals(cpf)) {
                System.out.println("Paciente já cadastrado!");
                return;
            }
        }

        System.out.print("Nome: ");
        String nome = sc.nextLine();
        System.out.print("Telefone: ");
        String tel = sc.nextLine();
        System.out.print("Data Nasc. (dd/mm/aaaa): ");
        String data = sc.nextLine();

        pacientes.add(new Paciente(cpf, nome, tel, data));
        log("Cadastrou paciente: " + nome);
        System.out.println("Paciente cadastrado!");
    }

    static void listarPacientes() {
        System.out.println("\n--- PACIENTES CADASTRADOS ---");
        if (pacientes.isEmpty()) {
            System.out.println("Nenhum paciente cadastrado.");
            return;
        }

        for (Paciente p : pacientes) {
            System.out.println(p.cpf + " - " + p.nome + " - " + p.telefone);
        }
        log("Listou pacientes");
    }

    static void editarPaciente() {
        System.out.print("\nCPF do paciente: ");
        String cpf = sc.nextLine();

        for (Paciente p : pacientes) {
            if (p.cpf.equals(cpf)) {
                System.out.print("Novo nome: ");
                p.nome = sc.nextLine();
                System.out.print("Novo telefone: ");
                p.telefone = sc.nextLine();
                log("Editou paciente: " + p.nome);
                System.out.println("Paciente atualizado!");
                return;
            }
        }
        System.out.println("Paciente não encontrado!");
    }

    static void removerPaciente() {
        System.out.print("\nCPF do paciente: ");
        String cpf = sc.nextLine();

        for (int i = 0; i < pacientes.size(); i++) {
            if (pacientes.get(i).cpf.equals(cpf)) {
                System.out.print("Remover " + pacientes.get(i).nome + "? (s/n): ");
                if (sc.nextLine().equalsIgnoreCase("s")) {
                    log("Removeu paciente: " + pacientes.get(i).nome);
                    pacientes.remove(i);
                    System.out.println("Paciente removido!");
                }
                return;
            }
        }
        System.out.println("Paciente não encontrado!");
    }

    static void agendarConsulta() {
        System.out.println("\n--- AGENDAR CONSULTA ---");

        System.out.print("CPF do paciente: ");
        String cpf = sc.nextLine();

        boolean existe = false;
        for (Paciente p : pacientes) {
            if (p.cpf.equals(cpf)) {
                existe = true;
                break;
            }
        }

        if (!existe) {
            System.out.println("Paciente não encontrado!");
            return;
        }

        System.out.print("Data (dd/mm/aaaa): ");
        String data = sc.nextLine();
        System.out.print("Hora (hh:mm): ");
        String hora = sc.nextLine();

        String id = "C" + contadorConsultas++;
        consultas.add(new Consulta(id, cpf, data, hora));
        log("Agendou consulta " + id);
        System.out.println("Consulta agendada! ID: " + id);
    }

    static void listarConsultas() {
        System.out.println("\n--- CONSULTAS AGENDADAS ---");
        if (consultas.isEmpty()) {
            System.out.println("Nenhuma consulta agendada.");
            return;
        }

        for (Consulta c : consultas) {
            System.out.println(c.id + " - " + c.cpfPaciente + " - " + c.data + " " + c.hora + " - " + c.status);
        }
        log("Listou consultas");
    }

    static void cancelarConsulta() {
        System.out.print("\nID da consulta: ");
        String id = sc.nextLine();

        for (Consulta c : consultas) {
            if (c.id.equals(id)) {
                c.status = "CANCELADA";
                log("Cancelou consulta " + id);
                System.out.println("Consulta cancelada!");
                return;
            }
        }
        System.out.println("Consulta não encontrada!");
    }

    static void relatorios() {
        System.out.println("\n--- RELATÓRIOS ---");
        System.out.println("1. Listar pacientes");
        System.out.println("2. Listar consultas");
        System.out.println("3. Consultas por data");
        System.out.print("Escolha: ");

        int op = Integer.parseInt(sc.nextLine());

        switch (op) {
            case 1: listarPacientes(); break;
            case 2: listarConsultas(); break;
            case 3:
                System.out.print("Data (dd/mm/aaaa): ");
                String data = sc.nextLine();
                System.out.println("\nConsultas em " + data + ":");
                for (Consulta c : consultas) {
                    if (c.data.equals(data)) {
                        System.out.println(c.id + " - " + c.cpfPaciente + " - " + c.hora);
                    }
                }
                break;
        }
        log("Gerou relatório");
    }

    static void cadastrarUsuario() {
        System.out.println("\n--- CADASTRAR USUÁRIO ---");

        System.out.print("Login: ");
        String login = sc.nextLine();

        for (Usuario u : usuarios) {
            if (u.login.equals(login)) {
                System.out.println("Login já existe!");
                return;
            }
        }

        System.out.print("Senha: ");
        String senha = sc.nextLine();
        System.out.print("Nome: ");
        String nome = sc.nextLine();
        System.out.print("Tipo (ADMIN/OPERADOR): ");
        String tipo = sc.nextLine().toUpperCase();

        if (!tipo.equals("ADMIN") && !tipo.equals("OPERADOR")) {
            System.out.println("Tipo inválido!");
            return;
        }

        usuarios.add(new Usuario(login, senha, nome, tipo));
        log("Cadastrou usuário: " + login);
        System.out.println("Usuário cadastrado!");
    }

    static void log(String acao) {
        try {
            FileWriter fw = new FileWriter("log.txt", true);
            fw.write(new Date() + " - " + usuarioAtual.login + " - " + acao + "\n");
            fw.close();
        } catch (IOException e) {
            System.out.println("Erro ao salvar log");
        }
    }
}

